"""
PEP: 8
Title: author
Author: Kevin Cook
Status: Active
Type: Process
Created: 26-October-2020
Post: 12-October-2020
History:
"""
def author():
    print("Kevin Cook is the author of this code")