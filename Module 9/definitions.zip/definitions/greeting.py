"""
PEP: 8
Title: greeting
Author: Kevin Cook
Status: Active
Type: Process
Created: 26-October-2020
Post: 12-October-2020
History:
"""
def greeting():
    print("Hello and Welcome")