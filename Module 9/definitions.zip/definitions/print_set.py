"""
PEP: 8
Title: print_set
Author: Kevin Cook
Status: Active
Type: Process
Created: 26-October-2020
Post: 12-October-2020
History:
"""
def print_set(setA):
    for x in set(setA):
        print(x, end=" ")